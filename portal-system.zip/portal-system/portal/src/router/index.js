import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/auth',
    name: 'Auth',
    component: () => import('../views/Auth.vue'),
    meta: { title: '登录/注册' },
  },
  {
    path: '/',
    component: () => import('../layouts/PortalLayout.vue'),
    children: [
      { path: '', name: 'Home', component: () => import('../views/Home.vue'), meta: { title: '首页' } },
      { path: 'features', name: 'Features', component: () => import('../views/Features.vue'), meta: { title: '功能详情' } },
      { path: 'docs', name: 'Docs', component: () => import('../views/Docs.vue'), meta: { title: '文档' } },
      { path: 'download', name: 'Download', component: () => import('../views/Download.vue'), meta: { title: '下载' } },
      { path: 'about', name: 'About', component: () => import('../views/About.vue'), meta: { title: '关于我们' } },
      { path: 'dashboard', name: 'Dashboard', component: () => import('../views/Dashboard.vue'), meta: { title: '用户中心', requiresAuth: true } },
      { path: 'dashboard/machines', name: 'Machines', component: () => import('../views/Machines.vue'), meta: { title: '机器管理', requiresAuth: true } },
      { path: 'dashboard/quota', name: 'Quota', component: () => import('../views/Quota.vue'), meta: { title: '生成次数', requiresAuth: true } },
    ],
  },
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('portal_token')
  const requiresAuth = to.matched.some((r) => r.meta.requiresAuth)
  if (requiresAuth && !token) {
    next('/auth')
  } else {
    next()
  }
})

export default router
